<footer>
    <div class="gri gri_footer">
   
        <div class="txt-alicen">
            <p>&copy;2023 RaleighElksLodge.com<p>
            <div class="genInfo_spacer"></div>
        </div>

        <div class="hide730">
            <p>Contact: 919-787-5990<p>
            <p>Email: RaleighElksLodge@gmail.com    
            <div class="genInfo_spacer"></div>   
        </div>
        
        <div class="txt-alicen">
             <p>Legal<p>
             <div class="genInfo_spacer"></div>   
        </div>

       

    </div>
</footer>