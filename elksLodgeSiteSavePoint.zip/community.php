<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Raleigh Elks | COMMUNITY</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700&display=swap" rel="stylesheet">
    <!--my css-->
    <link rel="stylesheet" href="styles.css">
    <!--js-->
    <!--seo-->
  
</head>

<body>


<div class="maincontainer">
    
    <img src="assets/comOutBan.png" class="banner pic1"  alt="">
    <img src="assets/elkMainMob2.png" class="banner pic2" alt="">

    <main>
    <?php include "navbar.php" ?>
 

        <section class="pad-comm-sec">
            <header class="flx flxdircol juscon alicen section_head_red comm-head">
                <h1 class="txt-alicen ">Hoop Shoot</h1>  
                <div class="red-line"></div>
            </header>

           
               
            <div class="gri gri-2 mar-comm-sec comm_bordRad">
                <div class="flx juscon alicen pd-1 bluebkg commPic1">
                    <div class="comm-img">
                        <img src="assets/comm1.png" alt="">
                    </div>
                </div>   
                
              
                <div class="flx">
                    <div class="flx flxdircol juscon  pd-1">
                        <p>
                            Introducing the Youth Hoop Shoot: Empowering Young Athletes Ages 8-13 with
                            a Free Throw Program. This exceptional initiative offers a remarkable chance
                            for youth to engage, compete, build connections, and thrive. To explore further
                            details and get involved, kindly reach out to:
                        </p>
                        <div class="genInfo_spacer"></div>
                        <div class="txt-alicen">
                            <h3>
                                Robert McAllister
                            </h3>
                            <h4>
                                (919) 954-1456 
                            </h4>
                            <h4>
                                robertmcalisterpainting<br>@gmail.com
                            </h4>
                        <div>
                        <div class="genInfo_spacer"></div>
                        <h4 class="commA">
                            <a href="https://www.elks.org/hoopshoot/" target="_blank"><u>www.elks.org/hoopshoot</u></a>
                        </h4>
                    </div>
                </div>
            </div>
               
        </section>

        <section class="sectDark pad-comm-sec">
             <header class="flx flxdircol juscon alicen section_head_red comm-head ">
                <h1 class="txt-alicen ">Durham V.A. Hospital</h1>  
                <div class="red-line"></div>
            </header>

            <div class="gri gri-2 mar-comm-sec comm_bordRad">
               
                <div class="flx">
                    <div class="flx flxdircol juscon pd-1 bkg-white">
                    <p>
                        The Elks are committed to their mission:<br>
                        “So long as there are veterans, the Benevolent and Protective Order of Elks will never forget them.”<br><br>
                        Raleigh Elks Lodge No. 735 proudly supports the Durham V.A. Medical Center as we dedicate our time and
                         fundraising to such a worthy hospital and its honored patients to whom we owe so much.<br>
                    </p>
                    <div class="genInfo_spacer"></div>
                  
                    
                    <h4 class="commA txt-alicen ">
                        <a href="https://www.va.gov/durham-health-care/" target="_blank"><u>www.durham.va.gov</u></a>
                    </h4>
                    </div>
                </div>

                <div class="flx juscon alicen pd-1 bluebkg commPic2">
                    <div class="comm-img">
                        <img src="assets/comm2.png" alt="">
                    </div>
                </div>  

            </div>
        </section>

        <section class="pad-comm-sec">
             <header class="flx flxdircol juscon alicen section_head_red comm-head">
                <h1 class="txt-alicen ">Raleigh Rescue Mission</h1>  
                <div class="red-line"></div>
            </header>

            <div class="gri gri-2 mar-comm-sec comm_bordRad">
                <div class="flx juscon alicen pd-1 bluebkg">
                    <div class="comm-img">
                        <img src="assets/comm3.png" alt="">
                    </div>
                </div>   
                
                <div class="flx">
                    <div class="flx flxdircol juscon pd-1">
                    <p>
                        The Raleigh Elks make regular visits to this amazing organization to donate, prepare,
                        and serve dinners to those in need.<br><br> 
                        From RRM's website: 
                        "Our goal is to help our clients restore their lives. Through recovery services, adult education, housing locator assistance, 
                        discipleship, and more.  Lives are transformed profoundly."
                    </p>
                    <div class="genInfo_spacer"></div>
                                
                    <h4 class="commA txt-alicen ">
                        <a href="https://www.raleighrescue.org/" target="_blank"><u>https://www.raleighrescue.org/</u></a>
                    </h4>
                    </div>
                </div>
            </div>
        </section>

        <section class="sectDark pad-comm-sec">
             <header class="flx flxdircol juscon alicen section_head_red comm-head">
                <h1 class="txt-alicen">ENF Scholarships</h1>  
                <div class="red-line"></div>
            </header>

            <div class="gri gri-2 mar-comm-sec comm_bordRad">
               
               <div class="flx">
                   <div class="flx flxdircol juscon  pd-1 bkg-white">
                   <p>
                    The Elks are dedicated to helping those in need to attend college. The Elks
                     National Foundation Scholarships provides funding for college scholarships annually 
                     through three different programs, the Most Valuable Student Scholarship, the Legacy Award, 
                     and the Emergency Educational Grant.
                   </p>
                   <div class="genInfo_spacer"></div>
                 
                   <h4 class="commA txt-alicen">
                       <a href="https://www.elks.org/scholars/" target="_blank"><u>https://www.elks.org/scholars/</u></a>
                   </h4>
                   </div>
               </div>

               <div class="flx juscon alicen pd-1 bluebkg">
                   <div class="comm-img">
                       <img src="assets/comm4.png" alt="">
                   </div>
               </div>  

           </div>
        </section>

        <?php include "footer.php" ?>
    </main>
</div>

    


</body>