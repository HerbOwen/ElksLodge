<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Raleigh Elks | JOIN</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700&display=swap" rel="stylesheet">
    <!--my css-->
    <link rel="stylesheet" href="styles.css">
    <!--js-->
    <!--seo-->
  
</head>

<body>

    <div class="maincontainer">
    
        <img src="assets/howToJoinBan.png" class="banner pic1"  alt="">
        <img src="assets/elkMainMob3.png" class="banner pic2" alt="">

        <main>
        <?php include "navbar.php" ?>

        <section class="don-sec2 flx flxdircol juscon alicen rel">    
            <header class="flx flxdircol juscon alicen section_head_red  ">
                    <h1>MEMBERSHIP</h1>
                    <div class="red-line"></div>
            </header> 
            
            <div class="flx flxdircol juscon  m-1">
                <h3 class="mt-half">Elks Care, Elks Share. Are <b>YOU</b> an Elk?</h3>
                    <p> 
                        Elks Lodges bring so much more to their communities than just a building,
                        golf course, or pool. They are places where neighbors come together, 
                        families share meals, and children grow up. Elks invest in their 
                        communities through programs that help children grow up healthy and
                        drug-free, by undertaking projects that address unmet needs, and by 
                        honoring the service and sacrifice of our veterans.  
                    </p>
           
                <h3 class="mt-half">
                    To be eligible for membership in the Benevolent and Protective Order of Elks, 
                    you must:
                </h3>
            
           
                <ul class="hind" >
                    <li>be a citizen of the United States</li>
                    <li>be over 21 years of age</li>
                    <li>believe in God</li>
                    <li>sponsored by a member of the Elks Lodge</li>
                    <li>reside in the jurisdiction of the Lodge you wish to join </li>
                    <li>have two other Elks agree to be your co-sponsor</li>
                </ul>
          
           
                <h3 class="mt-half">
                    If you meet the above criteria, here's how to apply:
                </h3>
            
           
                <h4 style="padding-top: .5rem;">
                    Membership Applicaton
                </h4>
            
            
                <ul class="hind">
                    <li>
                    The Elk who proposes you for membership must obtain a Membership Application from any Lodge or Lodge member. 
                    </li>
                    <li>
                    The proposing Elk must fill in the required portion of the Membership Application.  
                    </li>
                    <li>
                    When you receive the Membership Application, follow the instructions to complete the remaining sections.  
                    </li>
                    <li>
                    Return the completed application to the Lodge Secretary with the prescribed fees.  
                    </li>
                </ul>
                
            
                <h4 style="padding-top: .5rem;">
                    Aprroval Process
                </h4>
                
                <ul class="hind">
                    <li>Your application will be read at a regular Lodge meeting, then forwarded to the Investigating Committee.</li>
                    <li>The Investigating Committee will call you to set up a time for you and your sponsor to meet with the committee for an interview.</li>
                    <li>After the interview, the committee will report to the Lodge concerning your membership.</li>
                    <li>The members will be given a notice not less than ten days or more than two months before voting on your membership.​​</li>
                    <ul>
                        <li>If Approved</li>
                        <ul>
                            <li>You will be notified and asked to present yourself and your spouse for indoctrination.</li>
                            <li>During the indoctrination, you will learn more about the Order's programs and charities and set a date for your initiation. </li>
                            <li>After initiation as an Elk, you can then participate in all meetings and social functions of the Lodge.</li>
                        </ul>
                    </ul>
                    <ul>
                        <li>If not approved</li>
                        <ul>
                            <li>If your application is rejected for any reason, you cannot reapply for membership for six months from the date of rejection.</li>
                        </ul>
                    </ul>
                </ul>

                
                
            </div>   
                <div class="flx juscon alicen">
                    <h2 style="margin-top: 1rem;">JOIN US TODAY!</h2>   
                </div>
            </section>


        <?php include "footer.php" ?>
        </main>
    </div>

</body>