<footer>
    <div class="gri gri_footer">
        <div class="flx flxdircol alicen pd-half foot_col_1">
            <h4 class="txtalicen">CONTACT</h4>
            <div class="flx flxdircol juscon">
                <div class="flx juscon alicen">
                   <a href="tel:919-787-5990"><img src="assets/phone.png" class="phone" alt=""></a>
                </div>
                <div>
                    <p>(919) 787-5990</p>
                </div>
            </div>

            <div class="spacer_half"></div>
            <div class="spacer_half"></div>
            
            <div class="flx flxdircol juscon ">
                <div class="flx juscon alicen">
                    <a href="mailto:raleighelkslodge@gmail.com"><img src="assets/mail.png" class="phone2" alt=""></a>
                </div>
                <div>
                    <p>Raleighelkslodge@gmail.com</p>
                </div> 
            </div>

            <div class="spacer_half"></div>
            <div class="spacer_half"></div>

            <div class="flx flxdircol juscon">
                <div class="flx juscon alicen">
                    <a href="https://www.facebook.com/people/Raleigh-Elks-Lodge-735/100063531314157/"><img src="assets/fbim2.png" class="phone3" alt=""></a>
                </div>
                <div>
                    <p>Follow Us</p>
                </div> 
            </div>
                
        </div>

        <div class="flx flxdircol pd-half foot_col_2 ">
            <div class="foot_p_txtali">
                <h4>RENTAL OFFICE HOURS</h4>
                <p>Tuesday-Friday</p>
                <p>9:30am to 5:00pm</p>
                <div class="foot_hour_spacer">
                    <p>Saturday</p>
                    <p>10:00am to 2:00pm</p>
                </div>
                <div class="foot_hour_spacer">
                    <p>Sunday-Monday</p>
                    <p>Closed</p>
                </div>
            </div>
        </div>

        <div class="flx flxdircol pd-half foot_col_3">
            <div class="foot_p_txtali">
                <h4>MEMBER LOUNGE HOURS</h4>
                <p>Monday-Thursday:</p>
                <p>3:00pm to 10:00pm</p>
                <div class="foot_hour_spacer">
                    <p>Friday:</p>
                    <p>3:00pm to 12:00pm</p>
                </div>
                <div class="foot_hour_spacer">
                    <p>Saturday:</p>
                    <p>12:00pm to 10:00pm</p>
                </div>
                <div class="foot_hour_spacer">
                    <p>Sunday:</p>
                    <p>12:00pm to 8:00pm </p>
                </div>
            </div>
        </div>

    </div>
</footer>