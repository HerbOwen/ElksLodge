<header>
    

    <nav>
        <section>
            <div class="newsreel">
                <h2 class="news">Hats Fore Hearts: 12.18.2023<span class="event-spacing"></span>Golf Tournament: 10.16.2023<span class="event-spacing"></span>Chili Dog Cook-off: 11.19.2023</h2>
            </div>
        </section>

        <div class="navmain flx alicen spabet">
           
            <div class="nav_links_large juscon alicen">
                <ul class="flx">
                    <a href="index.php"><li class="active">HOME</li></a>
                    <a href="community.php"><li>COMMUNITY OUTREACH</li></a>
                    <a href="rental.php"><li>RENTAL FACILITIES</li></a>
                    <a href="howtojoin.php"><li>HOW TO JOIN</li></a>
                </ul>
                
            </div>
            <div class="burger flx flxend">
                <div>
                    <img src="assets/burgermenu.png" alt="">
                </div>
            </div>
        </div>
    </nav>

</header>

<script>
    window.addEventListener('load', function() {
        var navmain = document.querySelector('.navmain');
        var navmainOffset = navmain.offsetTop;
        var originalOffset = navmainOffset; // Store the original offset position

        window.addEventListener('scroll', function() {
            var scrollPosition = window.pageYOffset || document.documentElement.scrollTop;

            if (scrollPosition >= navmainOffset) {
                navmain.classList.add('sticky');
            } else {
                navmain.classList.remove('sticky');
            }

            // Adjust the original offset position if necessary
            if (scrollPosition < originalOffset) {
                originalOffset = scrollPosition;
            }
        });

        window.addEventListener('resize', function() {
            originalOffset = navmain.offsetTop; // Update the original offset on window resize
        });
    });
</script>