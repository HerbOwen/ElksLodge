<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Raleigh Elks | HOME</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700&display=swap" rel="stylesheet">
    <!--my css-->
    <link rel="stylesheet" href="styles.css">
    <script src="index.js" defer></script>
    <!--seo-->
  
</head>

<body>
    
    <div class="maincontainer">

        <img src="assets/elksfinal.png" class="banner pic1"  alt="">
        <img src="assets/elkMainMob.png" class="banner pic2" alt="">

        <main class="indexNav">

            <section class="elksHouseSection">
                <div class="elks_main_picture flx juscon alicen">
                   <img src="assets/elksCrib2.png" class="elkHousePhoto" alt="">
                </div>
            </section>  

            <?php include "navbar.php" ?>
          

            <section class="don-sec about_elks_sec flx flxdircol juscon rel">    
                <header class="flx flxdircol juscon alicen section_head_red  ">
                        <h1>ABOUT US </h1>
                        <div class="red-line"></div>
                </header> 
                
                <div class="flxabout pd-top1half spaaro pd-1">
                    <img src="assets/elksLogo.png" class="elkslogo" alt="">
                    
                    <div class="flx flxdircol alicen flx-item2 history_text">
                        
                        <h3>Our History</h3>
                        <p>Lor emipsum dolor sit amet consectetur adipisicing elit. Ad, architecto 
                            accusantium cumque dolores eveniet cum, enim molestiae dolorum aut 
                            veritatis quam repellat? Tempore doloribus unde deleniti molestias et doloremque quo!<br><br>

                            Lor emipsum dolor sit amet consectetur adipisicing elit. Ad, architecto 
                            accusantium cumque dolores eveniet cum, enim molestiae dolorum aut 
                            veritatis quam repellat? Tempore doloribus unde deleniti molestias et doloremque quo!
                        </p>    
                    </div>
                    
                    <div class="flx flxdircol alicen flx-item2 history_text">
                        <h3>Our Mission</h3>
                        <p>Elks Care, Elks Share, are YOU an Elk?<br><br>
                           Elks Lodges bring so much more to their communities than just a building, 
                           golf course or pool. They are places where neighbors come together, families 
                           share meals, and children grow up. <br><br> Elks invest in their communities through
                           programs that help children grow up healthy and drug-free, meet the needs of 
                           today's veterans, and improve the quality of life.
                        </p>
                    </div>
                </div>  
                
                <div class="flx spaaro aboutImagesSlide">
                    <img src="assets/aboutImgSlide.png" alt="">
                </div>

                <div class="flx spaaro aboutImagesSlide2">
                    <img src="assets/aboutImgSlide2.png" alt="">
                </div>

                <div class="flx spaaro aboutImagesSlide3">
                    <img src="assets/aboutImgSlide3.png" alt="">
                </div>

            </section>

            <section class="sectDark gen-info flx juscon flxdircol">
                <header class="flx flxdircol juscon alicen section_head_red ">
                    <h1 class="txt-alicen">GENERAL INFO</h1> 
                    <div class="red-line"></div>
                </header> 
                <div class="trying pd-1 ">
                    <div class="flx-item alicen juscon gen_card_bkg">
                            
                        <div class="home_hours_h4">
                            <h3 class="txt-alicen">News and Events</h3>
                        </div>
                        <div class="gri_home_intro txt-alicen "> 
                            <a href="elkCalen.php"><p class="event-pad"><u><b>July Calender of Events</b></u></p></a>
                            <a href="#"><p class="event-pad"><u><b>Random Other Cool Thing</b></u></p></a>
                            <a href="#"><p class="event-pad"><u><b>Whats Going down At Lodge 735</b></u></p></a>
                            <a href="#"><p class="event-pad"><u><b>Something to Say</b></u></p></a>
                            <a href="#"><p class="event-pad"><u><b>Pool Season Heating Up</b></u></p></a>
                        </div>
                    </div>
                    
                    <div class="flx-item alicen flxdircol gen_card_bkg ">
                        <div class="home_hours_h4">
                            <h3 class="txt-alicen">Member Lounge</h3>
                        </div>
                        <div class="gri_home_intro  txt-alicen"> 
                            <p><b>HOURS</b></p>
                            <div class="genInfo_spacer"></div>
                            <p><b>Monday-Thursday</b></p>
                            <p>3:00pm to 10:00pm</p>
                            <div class="genInfo_spacer"></div>
                            <p><b>Friday</b></p>
                            <p>3:00pm to 12:00pm</p>
                        
                            <div class="genInfo_spacer"></div>
                            <p><b>Saturday</b></p>
                            <p>12:00pm to 10:00pm</p>
                        
                            <div class="genInfo_spacer"></div>
                            <p><b>Sunday</b></p>
                            <p>12:00pm to 8:00pm </p>
                            <div class="genInfo_spacer"></div>
                        </div>
                    </div>

                    <div class="flx-item alicen flxdircol  gen_card_bkg">
                        <div class="home_hours_h4">
                            <h3 class="txt-alicen">Rental Office</h3>
                        </div>
                        <div class="gri_home_intro txt-alicen"> 
                            <p><b>HOURS</b></p>
                            <div class="genInfo_spacer"></div>  
                            <p><b>Tuesday-Friday</b></p>
                            <p>9:30am to 5:00pm</p>
                            <div class="genInfo_spacer"></div>
                            <p><b>Saturday</b></p>
                            <p>10:00am to 2:00pm</p>
                            <div class="genInfo_spacer"></div>
                            <p><b>Sunday-Monday</b></p>
                            <p>Closed</p>
                        </div>
                    </div> 
                </div>
            </section>

            <section class="don-sec flx flxdircol juscon">
                <div class="flx juscon alicen juscon donate_area flxdircol">
                    <div class="flx juscon flxdircol alicen section_head_red" >
                        <h1>DONATE TODAY</h1>
                        <div class="red-line"></div>
                    </div>
                    
                    <p class="donate_padding">
                        Here is where you explain to people where their donations go and why. Couple of paragraphs.
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. In atque veniam alias. Sed libero ad atque alias! Expedita 
                        veniam accusamus ex in, quibusdam culpa est, possimus obcaecati adipisci vitae facere.<br><br>

                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis numquam quam nam, atque eaque 
                        dolorem placeat reiciendis ab quisquam sint aliquam veritatis, delectus suscipit cupiditate quo 
                        culpa praesentium. Dolor, qui?
                    </p>
                    <a href="" class="a-border"><img src="assets/payLogo.png" class="a-border" alt=""></a>
                </div>
            </section>
     
           
            <section class="sectDark loc-sec flx juscon alicen flxdircol">
                <header class="flx flxdircol juscon alicen section_head_red">
                    <h1 class="txt-alicen">LOCATION</h1>
                    <div class="red-line"></div>
                </header>
                <div class="flx alicen juscon  pd-top1half pd-bot1half  ">
                    <div class="large_map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3233.7253235591947!2d-78.67232872360174!3d35.855738220367044!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89acf6332c4a52c3%3A0xb1c3ff8816425252!2sRaleigh%20Elks%20Lodge%20no.735!5e0!3m2!1sen!2sus!4v1688606389048!5m2!1sen!2sus" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div class="medium_map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3233.7253235591947!2d-78.67232872360174!3d35.855738220367044!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89acf6332c4a52c3%3A0xb1c3ff8816425252!2sRaleigh%20Elks%20Lodge%20no.735!5e0!3m2!1sen!2sus!4v1688606389048!5m2!1sen!2sus" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div class="small_map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3233.726742298642!2d-78.67078377120917!3d35.85570343771413!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89acf6332c4a52c3%3A0xb1c3ff8816425252!2sRaleigh%20Elks%20Lodge%20no.735!5e0!3m2!1sen!2sus!4v1688617933286!5m2!1sen!2sus" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div class="phone_map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3233.725500901847!2d-78.67232872401954!3d35.85573387253162!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89acf6332c4a52c3%3A0xb1c3ff8816425252!2sRaleigh%20Elks%20Lodge%20no.735!5e0!3m2!1sen!2sus!4v1688670483254!5m2!1sen!2sus" width="300" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </section>   
            
            <section class="con-info flx juscon flxdircol">
                <div class="flx flxdircol icobkground" >
                    <header class="flx flxdircol juscon alicen section_head_red">
                        <h1 class="txt-alicen">CONTACT INFO</h1>  
                        <div class="red-line"></div>
                    </header>
                
                    <div class="flx juscon alicen pd-top1half pd-bot1half">
                        <div class="flx flx-item flxend alicen pd-half">
                            <div class="flx flxdircol juscon alicen">
                                <a href="tel:919-787-5990"><img src="assets/phoneIco2.png" class="tpIco" alt=""></a>
                                <div>
                                    <h4 class="icon_head">(919) 787-5990</h4>
                                </div>
                            </div>
                        </div>
                        <div class="flx flx-item juscon alicen pd-half">
                            <div class="flx flxdircol juscon alicen">
                                <a href="mailto:raleighelkslodge@gmail.com" ><img src="assets/mailIco2.png" class="tpIco" alt=""></a>
                                <div>
                                    <h4 class="icon_head">Raleighelkslodge@gmail.com</h4>
                                </div>
                            </div>
                        </div>
                        <div class="flx flx-item flxbeg alicen pd-half">
                            <div class="flx flxdircol juscon alicen">
                                <a href="https://www.facebook.com/people/Raleigh-Elks-Lodge-735/100063531314157/"><img src="assets/fbIco2.png" class="tpIco" alt=""></a>
                                <div>
                                    <h4 class="icon_head">Follow Us</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section> 
        
            <?php include "footer.php" ?>                    
       
        </main>
 
    </div>  
</body>

</html>