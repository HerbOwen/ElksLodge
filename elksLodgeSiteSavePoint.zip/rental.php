<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Raleigh Elks | RENTAL</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700&display=swap" rel="stylesheet">
    <!--my css-->
    <link rel="stylesheet" href="styles.css">
    <!--js-->
    <!--seo-->
  
</head>

<body>

    <div class="maincontainer">
    
        <img src="assets/rentalBanner.png" class="banner pic1"  alt="">
        <img src="assets/elkMainMob4.png" class="banner pic2" alt="">

        <main>
        <?php include "navbar.php" ?>

        <section class="don-sec2 flx flxdircol juscon alicen rel">    
            <header class="flx flxdircol juscon alicen section_head_red  ">
                    <h1>Facility Rent Info</h1>
                    <div class="red-line"></div>
            </header> 
            
            <div class="flx flxdircol ">
                <p class="mt-half">
                The Raleigh Elks Lodge offers two beautifully appointed rooms that are available
                 for rent to the public, providing an exquisite venue for a variety of occasions.
                  Whether you're planning a memorable wedding reception, a joyous anniversary or 
                  birthday celebration, a festive holiday event, or a professional corporate 
                  gathering, our versatile spaces are perfect for any occasion.
                </p>
                <h3 class="mt-whole">
                    Location
                </h3>
                <p>
                Nestled on a 14-acre property at the intersection of Lead Mine and Millbrook
                roads, just a short distance from Crabtree Valley Mall, our venue provides a charming 
                setting for your special event. Ample free parking is available to accommodate your guests,
                ensuring convenience and ease of access. Additionally, we take pride in offering the option to
                host delightful outdoor weddings on our manicured lawns, adding a touch of natural 
                beauty to your celebration.
                </p>
                <h3 class="mt-whole">
                    Catering Services 
                </h3>
                <p>
                While we do not provide catering services, we offer the flexibility for you to select and utilize the catering service of your choice. Alternatively, our dedicated team is available to assist you in finding a reputable catering
                 service that aligns with your preferences and requirements.
                </p>
                <h3 class="mt-whole">
                    Beverage Services 
                </h3>
                <p>
                With great pride, we possess full ABC permits, granting us the privilege of curating a distinguished array of adult beverages for your event.
                </p>
                <h3 class="mt-whole">
                    Preperation for your event
                </h3>
                <p>
                Unlike many other venues, we have a policy of renting our space to only one party per day. This means you'll have plenty of time for decorating and setting up the venue just the way you envision it. No need to rush or compromise on your decorations - we give you the flexibility to create a personalized and memorable event that reflects your unique style and preferences.
                </p>
               
            </div>         
        
        </section>

        <div class="flx juscon colReverse juscon">
           
            <div class="flx flx-it juscon ">
                <div class="flxdircol juscon bd-chk2 bdrad-5 pd-1" >
                    <div>
                        <img src="assets/rental1.png" class="rentProb" alt="">
                    </div>
                    <div>
                        <div class="mt-whole flx juscon">
                            <h3>Annex</h3>
                        </div>
                        <div style="max-width: 300px;">
                            <ul class="hind">
                                <li>Accommodates up to 200 people (180 people seated)</li>
                                <li>Private entrance</li>
                                <li>Full-Service Bar available</li>
                                <li>Large dance floor</li>
                                <li>Large, private restrooms</li>
                                <li>Handicap Access</li>
                                <li>Great for large groups, wedding receptions, birthdays, anniversaries, retirement parties, 
                                    corporate meetings and much more!</li>
                                <li>Our 40' x 24' dance floor is one of the largest in Raleigh</li>
                                <li>Total room dimensions are 73' x 45'</li>
                                <li>An 8'x19' stage area as well as access to an outdoor patio</li>
                            </ul>
                        </div>
                    </div>
                </div>   
            </div>

            <div class="flx flx-it juscon ">
                <div class="flxdircol juscon bd-chk2 bdrad-5 pd-1" >
                        <div>
                            <img src="assets/rental2.png" class="rentProb" alt="">
                        </div>
                        <div class="flx juscon mt-whole">
                            <h3>Lower level</h3>
                        </div>
                        <div style="max-width:300px;">
                            <ul class="hind">
                                <li>Accomodates up to 80 people (64 seated)</li>
                                <li>Private entrance</li>
                                <li>Full-Service Bar available</li>
                                <li>Private restrooms</li>
                                <li>Located on the lower level</li>
                                <li>Handicap Access</li>
                                <li>Great for intimate gatherings such as birthdays, receptions, celebrations, and meetings.</li>
                                <li>Room to accomodate a DJ</li>
                                
                            </ul>
                        </div>
                    
                </div>   
            </div>
           
        </div>

        <section class="don-sec2 flx flxdircol juscon alicen rel">    
            <h3 class="mt-whole">
                Pricing
            </h3>
            <p>
            Prepare for an exceptional offer! Our prices for room rentals are designed to suit various budgets, ranging from a mere $600 to $2,000, depending on the room and the selected day of the week. What's even better? The quoted price includes the provision of tables and chairs, allowing you to focus on planning your event without any additional hassle or hidden costs. And guess what? We've got your back when it comes to cleanup too! Our dedicated team will take care of the final cleanup, ensuring a stress-free and seamless experience for you. 
            </p>

            <div class="mt-whole ">
                <img src="assets/rentInfo1.png" class="rentOne" alt="">
            </div>
            <div class="mt-whole rentTwo">
                <img src="assets/rentInfo2.png" class="rentTwo" alt="">
            </div>
            <div class="mt-whole rentThree">
                <img src="assets/rentInfo3.png" class="rentThree" alt="">
            </div>
          
            
            <div class="flx flxdircol">
               
                
            
                

            
                <h3 class="mt-whole">
                 Refreshments
                </h3>
                <ul class="hind">
                    <li>Bartender cost is $150 for the first three hours and $25/hour after that</li>
                    <li>White table cloth linens are $8 per table; white napkins are $1.50 per napkin. Colored linens are available 
                        upon special request.</li>
                    <li>Keg beer is available upon request:</li>
                    
                        <ul class="hind">
                            <li>1/2 Barrel of beer:  Average cost is $250 (serves approximately 175 12oz glasses) </li>
                            <li>1/6 Barrels of craft beer:  Average cost is $125 (serves approximately 56 12oz glasses) </li>
                            <li>1/4 Barrels of domestic beer:  Average cost is $125 (serves approximately 82 12oz glasses) </li>
                            <li>Prices may vary depending on the type of beer. </li>
                            <li>Unused kegs or portions thereof remain on the lodge premises after the event.  No refunds available for unused kegs as they are not ‘returnable’.</li>
                        </ul>
                    </li>
                    <li>Wine is $14.00 per 750ml bottle for house brands.  Special orders will be priced accordingly. </li>
                    <li>An 18% gratuity will be applied to all wine and keg beer purchases.</li>
                    <li>Water/soda packages are available and are priced based on your requirements.</li>
                </ul>
              
                  

         
                <h3 class="mt-whole">
                Rules
                </h3 class="mt-half">
                <ul class="hind">
                    <li>Setups must be completed on the day of the event and not the day before.  All personal property must be removed immediately following the end of the event.  We have no storage capabilities.</li>
                    <li>No events will go past midnight. Bar and event cutoff is 11:00 P.M. for either level room.</li>
                    <li>No outside alcohol is allowed on the premises.  All alcoholic beverages must be purchased at the Lodge and are not allowed to leave the interior of either rental area.</li>
                    <li>No use of the kitchen facilities by caterers or renters is permitted.</li>
                </ul>

                <h3 class="mt-whole">Essential Details</h3>
                <p >Outside areas are available at an additional cost.</p>
                <p>All rental prices include a one-day rental insurance policy.</p>
                <p>A refundable excessive cleaning/repair deposit is required:  $500 for the Annex / $250 for the Downstairs Meeting Room</p>
                <p>For larger parties, security is required at $35/hour.</p>
            </div>       

              
        
        </section>
       
        
        
        <?php include "footer.php" ?>
        </main>


  
    </div>

</body>