<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elks Calender</title>
    <link rel="stylesheet" href="styles.css">
    
</head>
<body>
    <div class="maincontainer">
         <?php include "navbar.php" ?>
      
        <div class="flx juscon alicen">
            <img src="assets/sampleCal.png" class="sampleCal" alt="">
        </div>
        <a href="index.php"><p>Home</p></a>
        <?php include "footer.php" ?>
    </div>

   

 
    
   
    
</body>
</html>